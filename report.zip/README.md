# Loughborough University MSc Advanced Computer Science Report Template

LaTeX Report Template for Loughborough University MSc Advacenced Computer Science Modules.

Adapted from [davestevens/Loughborough-University-PhD-Thesis-Template](https://github.com/davestevens/Loughborough-University-PhD-Thesis-Template).

## Usage

Run `make.bat` to generate `report.pdf`.

**Requirements:** TEX Live 2017+.



© Zhihao DAI 2019

